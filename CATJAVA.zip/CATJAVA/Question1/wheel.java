
/* on my honor, as rwanda polytechnic/IPRC Tumba student, i have neigther given nor received
unouthorised assistance on this work.
@author{ TUYISHIME Caleb}.
date january 25, 2021*/package wheel;
public class wheel{
	int count;
	int position;
	public wheel(){
		for (count=1; count<=4; count++) {
			System.out.println("I am a wheel NO: "+count);
		}
	}	
	void display(){

	}
}