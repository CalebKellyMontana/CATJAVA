/* on my honor, as rwanda polytechnic/IPRC Tumba student, i have neigther given nor received
unouthorised assistance on this work.
@author{ TUYISHIME Caleb}.
date january 25, 2021*/
package car;
import wheel.*;
import fluffyDice.*;
import engine.*;
import java.util.*;
class car{
	int count;
	String name;
	car(){
		System.out.println("car name: "+name);
	}
	void car(){

	}
	void setfluffyDice(){
		ArrayList<fluffyDice> flu=new ArrayList<fluffyDice>();
		fluffyDice b1=new fluffyDice("red");
		flu.add(b1);
	}
	void display(){

	}


}
class Controller2{
	public static void main(String[] args) {
		car car1=new car();
		engine engine1=new engine();
		engine1.displayeng();
		ArrayList<wheel> wheel1=new ArrayList<wheel>();
		wheel W1=new wheel();
		

	}
}