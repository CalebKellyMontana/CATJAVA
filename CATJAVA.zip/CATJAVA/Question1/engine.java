
/* on my honor, as rwanda polytechnic/IPRC Tumba student, i have neigther given nor received
unouthorised assistance on this work.
@author{ TUYISHIME Caleb}.
date january 25, 2021*/
package engine;
public class engine{
	public void displayeng(){
		System.out.println("engine: i am an engine");
	}
}