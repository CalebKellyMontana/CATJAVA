/* on my honor, as rwanda polytechnic/IPRC Tumba student, i have neigther given nor received
unouthorised assistance on this work.
@author{ TUYISHIME Caleb}.
date january 25, 2021*/
package fluffyDice;
import java.util.*;
public class fluffyDice{
	String color;
	public fluffyDice(String color){
		this.color=color;
		
		ArrayList<fluffyDice> flu=new ArrayList<fluffyDice>();
		fluffyDice b1=new fluffyDice("red");
		flu.add(b1);
		for (fluffyDice fl:flu) {
			System.out.println(fl);
		}
	}
	void display(){

	}

}