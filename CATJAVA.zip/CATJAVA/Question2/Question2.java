/* on my honor, as rwanda polytechnic/IPRC Tumba student, i have neigther given nor received
unouthorised assistance on this work.
@author{ TUYISHIME Caleb}.
date january 25, 2021*/
//package Question1;
//package Question1;
class Item{
	String name;
	String category;
	double price;
	int Item(String name, String category, double price){
		return 0;
	}
}
class Property extends Item{
	int bedroom;
	int area;
	int age;
	Property(String name, String category, double price, int bedroom,int area,int age){
		this.name=name;
		this.category=category;
		this.price=price;
		System.out.println("Property");
		System.out.println("Name: "+name+"\ncategory: "+category+"\nprice: "+price+"\nBedroom: "+bedroom+"\narea: "+area+"\nage: "+age);
		System.out.println("===================");
	}
	void display(){
		
	}
}
class Household extends Item{
	String condition;
	String picture;
	Household(String name, String category, double price, String condition, String picture){
		this.name=name;
		this.category=category;
		this.price=price;
		System.out.println("===================");
		System.out.println("Household");
		System.out.println("Name: "+name+"\ncategory: "+category+"\nprice: "+price+"\nCondition: "+condition+"\npicture: "+picture);
		
	}
}
class Car extends Item{
	String plateNumber;
	String manufactured;
	Car(String name, String category, double price, String plateNumber, String manufactured){
		this.name=name;
		this.category=category;
		this.price=price;
		System.out.println("Car");
		System.out.println("Name: "+name+"\ncategory: "+category+"\nprice: "+price+"\nPlateNumber: "+plateNumber+"\nManufactured: "+manufactured);
	}
	void display(){

	}
}
class Controller{
	public static void main(String[] args) {
		//Controller dat= new Controller();
		Property datt= new Property("Hoouse","Property",100000.0,5,600,5);
		Car dattt=new Car("BMW","Utility",5000000.0,"RAB123B","Thu jan 01 0:00:09 CAT 1970");
		Household datttt=new Household("flask","Utility",5000.0,"used","http://www.picture.com/flask");
	}
}